
package examples.mapreduce.salescountry;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
//import org.apache.hadoop.mapred.*;

//import org.apache.hadoop.mapred.JobClient;
//import org.apache.hadoop.mapred.JobConf;
//import org.apache.hadoop.mapred.TextInputFormat;
//import org.apache.hadoop.mapred.TextOutputFormat;
//import org.apache.hadoop.mapred.FileInputFormat;
//import org.apache.hadoop.mapred.FileOutputFormat;

public class SalesCountryDriver {
	public static void main(String[] args) {
//JobClient
		org.apache.hadoop.mapred.JobClient my_client = new org.apache.hadoop.mapred.JobClient();
//JobConf
		org.apache.hadoop.mapred.JobConf job_conf = new org.apache.hadoop.mapred.JobConf(SalesCountryDriver.class);

		// Set a name of the Job
		job_conf.setJobName("SalePerCountry");

		// Specify data type of output key and value
		job_conf.setOutputKeyClass(Text.class);
		job_conf.setOutputValueClass(IntWritable.class);

//Maper
		job_conf.setMapperClass(examples.mapreduce.salescountry.SalesMapper.class);
//Reducer
		job_conf.setReducerClass(examples.mapreduce.salescountry.SalesCountryReducer.class);

		// Specify formats of the data type of Input and output
		job_conf.setInputFormat(org.apache.hadoop.mapred.TextInputFormat.class);
		job_conf.setOutputFormat(org.apache.hadoop.mapred.TextOutputFormat.class);

		// Set input and output directories using command line arguments, 
		//arg[0] = name of input directory on HDFS, and arg[1] =  name of output directory to be created to store the output file.
		
		org.apache.hadoop.mapred.FileInputFormat.setInputPaths(job_conf, new Path(args[0]));
		org.apache.hadoop.mapred.FileOutputFormat.setOutputPath(job_conf, new Path(args[1]));

		my_client.setConf(job_conf);
		try {
// Run the job 
			org.apache.hadoop.mapred.JobClient.runJob(job_conf);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
